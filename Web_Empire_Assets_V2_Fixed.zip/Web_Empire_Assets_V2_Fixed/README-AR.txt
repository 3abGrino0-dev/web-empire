Web Empire Assets V2 — إصلاح تركيب الصور

الإصلاحات:
- إصلاح رابط الشعار المكسور في الهيدر.
- شعار أفقي بخلفية شفافة وقص محكم.
- صورة Hero بقص أفضل.
- صورة Dashboard أفقية بدل الصورة العمودية الطويلة.
- منع بطاقة الأسعار من التمدد بسبب صورة Dashboard.
- CSS متجاوب للجوال وسطح المكتب.

طريقة التطبيق:
1. ارفع الملف المضغوط إلى Codespaces.
2. فك الضغط.
3. شغّل:
   bash Web_Empire_Assets_V2_Fixed/apply-assets-v2.sh

ثم أنشئ Preview بدون --prod:
   npx --yes vercel@latest --yes --logs --meta "githubCommitRef=feat/v5-ui-closeout"
