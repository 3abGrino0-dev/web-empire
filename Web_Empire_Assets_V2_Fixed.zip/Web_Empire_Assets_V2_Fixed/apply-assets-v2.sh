#!/usr/bin/env bash
set -eo pipefail
export rvm_bash_nounset=1

PACK_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="${1:-/workspaces/web-empire}"
BRANCH="feat/v5-ui-closeout"

cd "$PROJECT_DIR"

if [ "$(git branch --show-current)" != "$BRANCH" ]; then
  git switch "$BRANCH"
fi

git pull --ff-only origin "$BRANCH"

if [ -n "$(git status --porcelain)" ]; then
  echo "STOP: الشجرة غير نظيفة."
  git status --short
  exit 1
fi

cp -f "$PACK_DIR"/public/brand/* public/brand/
cp -f "$PACK_DIR"/src/brand/web-empire-light-assets.ts src/brand/web-empire-light-assets.ts

python3 <<'PY'
from pathlib import Path

header = Path("src/components/site-header.tsx")
text = header.read_text(encoding="utf-8")
import_line = 'import { webEmpireLightAssets } from "@/brand/web-empire-light-assets";\n'

if import_line not in text:
    text = text.replace(
        'import Link from "next/link";\n',
        'import Link from "next/link";\n\n' + import_line,
        1,
    )

text = text.replace(
    'src="/brand/web-empire-logo.svg"',
    'src={webEmpireLightAssets.logo}',
)

header.write_text(text, encoding="utf-8")

css = Path("src/app/web-empire-light.css")
css_text = css.read_text(encoding="utf-8")

start = "/* WEB EMPIRE ASSET FIT V2 START */"
end = "/* WEB EMPIRE ASSET FIT V2 END */"
block = '/* WEB EMPIRE ASSET FIT V2 START */\n\n.light-empire-brand-logo {\n  display: block;\n  width: clamp(155px, 15vw, 210px);\n  max-width: 100%;\n  height: auto;\n  object-fit: contain;\n}\n\n.we-hero-visual {\n  min-height: 0;\n  aspect-ratio: 16 / 9;\n  overflow: visible;\n  background: transparent;\n}\n\n.we-hero-visual img {\n  display: block;\n  width: 100%;\n  height: 100%;\n  object-fit: contain;\n  object-position: center;\n  background: transparent;\n  mix-blend-mode: multiply;\n  filter: drop-shadow(0 28px 54px rgba(16, 19, 31, 0.08));\n}\n\n.we-bottom-grid {\n  align-items: stretch;\n}\n\n.we-dashboard-card,\n.we-pricing-panel {\n  min-height: 0;\n  align-self: stretch;\n}\n\n.we-dashboard-card {\n  display: flex;\n  flex-direction: column;\n}\n\n.we-dashboard-card img {\n  display: block;\n  width: 100%;\n  height: auto;\n  aspect-ratio: 12 / 7;\n  object-fit: cover;\n  object-position: center;\n  margin-top: 16px;\n  border: 1px solid var(--we-line);\n  border-radius: 18px;\n  background: #fff;\n}\n\n.we-dashboard-preview {\n  width: min(100%, 660px);\n  height: auto;\n  aspect-ratio: 12 / 7;\n  object-fit: cover;\n  object-position: center;\n  border-radius: 18px;\n}\n\n.we-pricing-visual img,\n.we-pricing-hero img {\n  width: 100%;\n  height: auto;\n  object-fit: contain;\n  object-position: center;\n  mix-blend-mode: multiply;\n}\n\n@media (max-width: 1024px) {\n  .we-hero-visual {\n    width: min(760px, 100%);\n    margin-inline: auto;\n  }\n\n  .we-dashboard-card img,\n  .we-dashboard-preview {\n    aspect-ratio: 16 / 10;\n  }\n}\n\n@media (max-width: 680px) {\n  .light-empire-brand-logo {\n    width: 158px;\n  }\n\n  .we-hero-visual {\n    aspect-ratio: 4 / 3;\n  }\n\n  .we-dashboard-card img,\n  .we-dashboard-preview {\n    aspect-ratio: 4 / 3;\n  }\n}\n\n/* WEB EMPIRE ASSET FIT V2 END */'

if start in css_text and end in css_text:
    before = css_text.split(start, 1)[0]
    after = css_text.split(end, 1)[1]
    css_text = before.rstrip() + "\n\n" + block + "\n" + after.lstrip()
else:
    css_text = css_text.rstrip() + "\n\n" + block + "\n"

css.write_text(css_text, encoding="utf-8")
PY

git diff --check
npm run typecheck
npm run lint
npm run build

git add \
  public/brand \
  src/brand/web-empire-light-assets.ts \
  src/components/site-header.tsx \
  src/app/web-empire-light.css

git commit -m "fix(assets): fit Web Empire visuals and repair logo path"
git push

echo "ASSET_V2_COMMIT=$(git rev-parse HEAD)"
echo "ASSET_V2_BRANCH=$(git branch --show-current)"
git status --short
